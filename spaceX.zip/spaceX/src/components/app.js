import React, { Component } from 'react'
import LaunchTable from '../containers/launch_table'

export default class App extends Component {
  render () {
    return (
      <LaunchTable />
    )
  }
}
