import axios from 'axios'

export const GET_LAUNCHES = 'GET_LAUNCHES'
const URL = 'https://api.spacexdata.com/v2/launches'

export function getLaunches () {
  const request = axios.get(URL)
  return {
    type: GET_LAUNCHES,
    payload: request
  }
}
