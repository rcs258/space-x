import React, { Component } from 'React'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { getLaunches } from '../actions/index'

class LaunchTable extends Component {
  constructor (props) {
    super(props)
    this.state = {data: []}
  }
  componentDidMount () {
    this.props.getLaunches()
  }
  componentDidUpdate () {
    this.setState({data: this.props.launches})
  }
  sortArray (value) {
    if (this.props.launches) {
      switch (value) {
        case 'name':
          this.props.launches.sort(function (a, b) { return (a.rocket.rocket_name > b.rocket.rocket_name) ? 1 : ((b.rocket.rocket_name > a.rocket.rocket_name) ? -1 : 0) })
          this.setState({data: this.props.launches})
          break
        case 'type':
          this.props.launches.sort(function (a, b) { return (a.rocket.rocket_type > b.rocket.rocket_type) ? 1 : ((b.rocket.rocket_type > a.rocket.rocket_type) ? -1 : 0) })
          this.setState({data: this.props.launches})
          break
        case 'date':
          this.props.launches.sort(function (a, b) { return (a.launch_date_local > b.launch_date_local) ? 1 : ((b.launch_date_local > a.launch_date_local) ? -1 : 0) })
          this.setState({data: this.props.launches})
          break
        case 'details':
          this.props.launches.sort(function (a, b) { return (a.details > b.details) ? 1 : ((b.details > a.details) ? -1 : 0) })
          this.setState({data: this.props.launches})
          break
        case 'id':
          this.props.launches.sort(function (a, b) { return (a.flight_number > b.flight_number) ? 1 : ((b.flight_number > a.flight_number) ? -1 : 0) })
          this.setState({data: this.props.launches})
          break
        case 'article':
          this.props.launches.sort(function (a, b) { return (a.article_link > b.article_link) ? 1 : ((b.article_link > a.article_link) ? -1 : 0) })
          this.setState({data: this.props.launches})
          break
        case 'badge':
          this.props.launches.sort(function (a, b) { return (a.links.mission_patch > b.links.mission_patch) ? 1 : ((b.links.mission_patch > a.links.mission_patch) ? -1 : 0) })
          this.setState({data: this.props.launches})
          break
      }
    }
  }
  renderLaunchTable (launchData) {
    var date = new Date(launchData.launch_date_local)
    const launchDate = (date.getMonth() + 1) + '/' + date.getDate() + '/' + date.getFullYear()
    return (
      <tr>
        <td><img className='mission-image' src={launchData.links.mission_patch} /></td>
        <td>{launchData.rocket.rocket_name}</td>
        <td>{launchData.rocket.rocket_type}</td>
        <td>{launchDate}</td>
        <td>{launchData.details}</td>
        <td>{launchData.flight_number}</td>
        <td><a href={launchData.links.article_link}>Link</a></td>
      </tr>
    )
  }
  render () {
    return (
      <table>
        <thead>
          <tr>
            <th onClick={() => this.sortArray('badge')}>Badge</th>
            <th onClick={() => this.sortArray('name')}>Rocket Name</th>
            <th onClick={() => this.sortArray('type')}>Rocket Type</th>
            <th onClick={() => this.sortArray('date')}>Launch Date</th>
            <th onClick={() => this.sortArray('details')}>Details</th>
            <th onClick={() => this.sortArray('id')}>ID</th>
            <th onClick={() => this.sortArray('article')}>Article</th>
          </tr>
        </thead>
        <tbody>
          {(this.state.data ? this.state.data.map(this.renderLaunchTable) : '')}
        </tbody>
      </table>
    )
  }
}

function mapStateToProps ({ launches }) {
  return { launches }
}

function mapDispatchToProps (dispatch) {
  return bindActionCreators({getLaunches}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(LaunchTable)
