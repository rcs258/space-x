import { combineReducers } from 'redux'
import Launches from './get_launches'

const rootReducer = combineReducers({
  state: (state = {}) => state,
  launches: Launches
})

export default rootReducer
