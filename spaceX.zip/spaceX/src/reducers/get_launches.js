import { GET_LAUNCHES } from '../actions/index'

export default function (state = null, action) {
  switch (action.type) {
    case GET_LAUNCHES:
      return action.payload.data
  }
  return state
}
